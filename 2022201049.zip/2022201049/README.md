Question 1 :

1) Firstly I have used wc command to find the number of lines
2) Then I have founded the Middle Line number by handling case of even and odd. 
eg if n = 5 then middle line will be 3 and if n = 6 then middle line will also be 3
3) In the last step I have used head command to get all the lines till the middle line 
and then piped this to tail -1 so that I wil get the last line and this line will be our middle line.


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Questions 2:

awk command is used in this to manipulate plain text to tabular format by using Field separator "\". 
So I got all my data using /etc/shells and separated using  "\" and then I have filtered data by using '/usr/'
At the end I have used {print $NF} to get last column which contain all the user names.
