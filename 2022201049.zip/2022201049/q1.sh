#! /bin/bash

totalLines=$(cat $1 | wc -l)

if [ $((totalLines%2)) -eq 0 ]
then 
	middle=$((totalLines/2))
else
	middle=$((totalLines/2 + 1))
fi
	

cat $1 | head -$middle | tail -1


